import bots
# import pexpect

# child = pexpect.spawn(bots.bot_estrategia1_testing())
# child.expect('apikey: ')
# child.expect('secKey: ')

bots.bot_backtesting_estrategia1()